﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace StudentPortal.Models
{
    public class Student
    {
        [Key]
        public int StudentId { get; set; }

        [Column(TypeName = "int")]
        [Required(ErrorMessage = "Please enter ID Number.")]

        [DisplayName("Identity Number")]
        public int StudentTz { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        [Required(ErrorMessage = "Please enter Full Name.")]
       
        [DisplayName("Full Name")]
        public string FullName { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        [DisplayName("Email Address")]
        [DataType(DataType.EmailAddress,ErrorMessage ="Invalid Email Address.")]        
        public string EmailAddress { get; set; }

        [Column(TypeName = "Date")]
        [DisplayName("Birth Date")]
        [DataType(DataType.Date)]

        [Required(ErrorMessage = "Please enter Birth Date.")]

        public DateTime BirthDate { get; set; }

        [Column(TypeName = "int")]
        [DisplayName("Gender")]
        public GenderTypes? Gender { get; set; }

        [Column(TypeName = "int")]
        [DisplayName("Phone")]

        public int Phone { get; set; }

    }

    public enum GenderTypes
    {
       Male=0,
       Female=1,
       Other=2,    
    }
  


}
